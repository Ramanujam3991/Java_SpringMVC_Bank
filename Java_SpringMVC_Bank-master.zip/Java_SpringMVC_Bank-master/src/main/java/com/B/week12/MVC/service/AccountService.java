package com.B.week12.MVC.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

import com.B.week12.MVC.dao.AccountDao;
import com.B.week12.MVC.dao.IAccountDao;
import com.B.week12.MVC.model.Account;
import com.B.week12.MVC.model.CheckBalance;
import com.B.week12.MVC.model.DepositMoney;
import com.B.week12.MVC.model.Transaction;
import com.B.week12.MVC.model.WithdrawMoney;

public class AccountService implements IAccountService {
	public AccountDao accountDao;
	public IAccountDao iAccountDao;

	public void setAccountDao(AccountDao accountDAO) {
		this.accountDao = accountDAO;
	}

	public Account getAccountDetails(HashMap<String, String> dataMap) {
		// TODO Auto-generated method stub
		return iAccountDao.getAccountDetails(dataMap);
	}

	public Transaction getTransactionDetails(HashMap<String, String> dataMap) {
		// TODO Auto-generated method stub
		return iAccountDao.getTransactionDetails(dataMap);
	}

	public boolean depositAccount(DepositMoney account) {
		return AccountDao.depositAccount(account.getAccount_No(), account.getUserName(), account.getPassword(),
				account.getAmount());

	}

	public boolean withdrawMoney(WithdrawMoney account) {
		return accountDao.withDrawMoney(account.getAccount_No(), account.getUserName(), account.getPassword(),
				account.getAmount());
	}
	
	public int checkBalance(CheckBalance account) {
		// TODO Auto-generated method stub
		return accountDao.checkBalance(account.getAccount_No(),account.getUserName(),account.getPassword());
	}
	public Account showMyAccountDAO(Object obj) {

		if (obj.getClass().getName().equals("com.B.week12.MVC.DAO.WithdrawMoney")) {
			WithdrawMoney with = (WithdrawMoney) obj;
			System.out.println("withder ok from OBject");
			return accountDao.showMyAccountDAO(with.getAccount_No());
		}

		if (obj.getClass().getName().equals("com.sakib.eBanking.DAO.DepositMoney")) {
			DepositMoney with = (DepositMoney) obj;
			return accountDao.showMyAccountDAO(with.getAccount_No());
		}
		System.out.println("withdraw not ok from OBject: " + obj.getClass().getName().toString());
		return new Account();
	}
}
