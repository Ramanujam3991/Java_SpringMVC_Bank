package com.B.week12.MVC.model;

public class DepositMoney {

	private String userName;
	private String password;
	private String account_No;
	private String amount;

	public DepositMoney() {

	}

	public DepositMoney(String userName, String password, String amount, String account_No) {

		this.userName = userName;
		this.password = password;
		this.account_No = account_No;
		this.amount = amount;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getAccount_No() {
		return account_No;
	}

	public void setAccount_No(String account_No) {
		this.account_No = account_No;
	}

}