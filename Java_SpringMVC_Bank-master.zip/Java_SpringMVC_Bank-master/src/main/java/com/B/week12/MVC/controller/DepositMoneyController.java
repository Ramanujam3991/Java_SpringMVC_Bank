package com.B.week12.MVC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import com.B.week12.MVC.model.Account;
import com.B.week12.MVC.model.DepositMoney;
import com.B.week12.MVC.service.AccountService;

public class DepositMoneyController {

	public AccountService accountService;

	@Autowired
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}

	@RequestMapping("/depositAccount")
	public String depositAccount(Model model) {

		model.addAttribute(new DepositMoney());

		return "depositAcc";
	}

	@RequestMapping("/okDeposit")
	public String okDeposit(Model model, @Value(value = "") DepositMoney account, BindingResult result) {

		if (result.hasErrors()) {
			return "depositAcc";
		}
		if (accountService.depositAccount(account)) {
			Account acc = accountService.showMyAccountDAO(account);
			model.addAttribute("myaccount", acc);
			return "depositedAcc";
		}
		model.addAttribute("error", "Invalid Account Number, UserName or Password");
		return "depositAcc";
	}
}
