package com.B.week12.MVC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import com.B.week12.MVC.service.AccountService;


import com.B.week12.MVC.model.CheckBalance;

public class CheckBalanceController {
	
	public AccountService accountService;
	
	@Autowired
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}

	@RequestMapping("/checkBalance")
	public String checkBalance(Model model) {

		model.addAttribute(new CheckBalance());

		return "checkBalance";
	}
	
	@RequestMapping("/okCheckBalance")
	public String okCheckBalance(Model model,@Value(value = "") CheckBalance account,BindingResult result) {

		if (result.hasErrors()) {
			return "checkBalance";
		}
		int balance=accountService.checkBalance(account);
		if (balance>=0) {
			model.addAttribute("balance", balance);
			return "checkBalanceOk";
		}
		model.addAttribute("error", "Invalid Account Number, UserName or Password");
			return "checkBalance";
		
	}

}
