package com.B.week12.MVC.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.B.week12.MVC.dao.IUserDao;
import com.B.week12.MVC.model.*;

public class UserService implements IUserService {

	  @Autowired
	  public IUserDao iUserDao;

	  public int register(Account account) {
	    return iUserDao.register(account);
	  }

	  public User validateUser(Login login) {
	    return iUserDao.validateUser(login);
	  }

	public User getUser(int user_id) {
		// TODO Auto-generated method stub
		return iUserDao.getUser(user_id);
	}	  
	
	public Account getAccount(int user_id) {
		return iUserDao.getAccount(user_id);

	}
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return iUserDao.getAllAccounts();
	}
	
	public Account tranferFunds(Account account,Account account2,double fund) {
		return iUserDao.tranferFunds(account, account2, fund);
	}



	}