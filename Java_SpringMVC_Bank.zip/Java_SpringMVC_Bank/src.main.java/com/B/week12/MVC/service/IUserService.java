package com.B.week12.MVC.service;

import java.util.List;

import com.B.week12.MVC.model.Account;
import com.B.week12.MVC.model.Login;
import com.B.week12.MVC.model.User;

public interface IUserService {

	 int register(Account account);
	 User validateUser(Login login);
	  
	 User getUser(int user_id);
	 
	 Account getAccount(int user_id);
	 List<Account> getAllAccounts();
	 
	 Account tranferFunds(Account account,Account account2,double fund);

		 
	  
	  
}