package com.B.week12.MVC.controller;

import java.util.List;
import java.util.stream.Collectors;  


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.B.week12.MVC.model.Account;
import com.B.week12.MVC.model.Login;
import com.B.week12.MVC.model.User;
import com.B.week12.MVC.service.IUserService;
import com.B.week12.MVC.service.UserService;


@Controller
public class DashboardController {

	  
	  @Autowired
	  public IUserService iUserService;
	  
	  
	  @RequestMapping(value = "/Dashboard/{user_id}", method = RequestMethod.GET)
		public ModelAndView dashboard(@PathVariable(value = "user_id") int user_id,
				HttpServletRequest request, HttpServletResponse response, Model m) {
			System.out.println("Dashboard contoller user_id:" + user_id);

			ModelAndView mav = new ModelAndView("Dashboard");
			System.out.println("Enters Dashboard View");
			//HttpSession session = request.getSession();
			//String role = (String) session.getAttribute("role");
			//System.out.println("User role:" + role);
			//Reservation reservation = reservationService.getReservation(user_id);
			User user = iUserService.getUser(user_id);
			Account account = iUserService.getAccount(user_id);
			List<Account> accountlst = iUserService.getAllAccounts();

			
			System.out.println("Controller User "+ user.getUser_name());
//			System.out.println("Controller Account "+ account.getAccount_id()+" "+account.getCurrent_balance());
			m.addAttribute("accountlst",accountlst);


//			List<Reservation> reservationLst = reservationService.getAllReservation();
//			m.addAttribute("reservationLst", reservationLst);
			mav.addObject("user", user);
			mav.addObject("account", account);
			return mav;
		}
}
