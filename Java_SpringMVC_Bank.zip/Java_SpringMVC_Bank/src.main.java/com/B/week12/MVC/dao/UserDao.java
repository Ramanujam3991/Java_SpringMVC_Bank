package com.B.week12.MVC.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.B.week12.MVC.model.Account;
import com.B.week12.MVC.model.Login;
import com.B.week12.MVC.model.User;

public class UserDao implements IUserDao {

	@Autowired
	DataSource datasource;

	@Autowired
	JdbcTemplate jdbcTemplate;

	public int register(Account account) {
		User user = account.getUser();
		System.out.println("Data:" + user);
		String sql = "insert into user(user_name,password,first_name, last_name,email,address,phone) values(?,?,?,?,?,?,?)";

		jdbcTemplate.update(sql, new Object[] { user.getUser_name(), user.getPassword(), user.getFirst_name(),
				user.getLast_name(), user.getEmail(), user.getAddress(), user.getPhone() });

		sql = "insert into login(user_name, password) values(?,?)";

		 jdbcTemplate.update(sql, new Object[] { user.getUser_name(), user.getPassword() });
		
		sql = "insert into account(user_id, account_type) values((select user_id from user where user_name=?),?)";

		return jdbcTemplate.update(sql, new Object[] { user.getUser_name(), account.getAccount_type() });
	}

	public User validateUser(Login login) {
		System.out.println(login.getUsername());
		System.out.println(login.getPassword());

		
		String sql = "select * from user where user_name='" + login.getUsername() + "' and password='"
				+ login.getPassword() + "'";
		System.out.println("SQL:" + sql);
		List<User> users = jdbcTemplate.query(sql, new UserMapper());

		return users.size() > 0 ? users.get(0) : null;
	}

	public User getUser(int user_id) {
		// TODO Auto-generated method stub
		String sql="select *  from user where user_id='"+user_id+"'";
		System.out.println(sql);
		System.out.println("getUser()-Dao Class");
		User user = jdbcTemplate.queryForObject(sql, new UserMapper());
		System.out.println("user:"+user.getUser_id()+" "+ user.getUser_name());
		return user;
	}
	public List<Account> getAllAccounts() {
		return jdbcTemplate.query("select * from account", new AccountUserMapper());
	}
	public Account getAccount(int user_id) {
		// TODO Auto-generated method stub
		String sql="select *  from account where user_id='"+user_id+"'";
		System.out.println(sql);
		System.out.println("getAccount()-Dao Class");
		Account account = jdbcTemplate.queryForObject(sql, new AccountUserMapper());
//		System.out.println("account:"+account.getUser_id()+" "+ account.getCurrent_balance());
		return account;
	}
	
	public Account tranferFunds(Account account,Account account2,double fund) {
		System.out.println("TransferFunds:");
		double balance = account.getCurrent_balance()-fund;
		String sql = "update account set current_balance="+balance+" where account_id=?";

		jdbcTemplate.update(sql,
				new Object[] { account.getCurrent_balance()});
		
		double balance2 = account2.getCurrent_balance()+fund;
		String sql2 = "update account set current_balance="+balance2+" where account_id=?";

		jdbcTemplate.update(sql2,
				new Object[] { account2.getCurrent_balance()});

		return account;

		
	}
	
	

}

class UserMapper implements RowMapper<User> {

	public User mapRow(ResultSet rs, int arg1) throws SQLException {
		User user = new User();
		user.setUser_id(rs.getInt("user_id"));
		user.setUser_name(rs.getString("user_name"));
		user.setPassword(rs.getString("password"));
		user.setFirst_name(rs.getString("first_name"));
		user.setLast_name(rs.getString("last_name"));
		user.setEmail(rs.getString("email"));
		user.setAddress(rs.getString("address"));
		user.setPhone(rs.getString("phone"));

		return user;
	}

}



class AccountUserMapper implements RowMapper<Account> {

	public Account mapRow(ResultSet rs, int arg1) throws SQLException {
		Account account = new Account();
		account.setAccount_id(rs.getInt("account_id"));
		account.setAccount_status(rs.getString("account_status"));
		account.setAccount_type(rs.getString("account_Type"));
		account.setCurrent_balance(rs.getDouble("current_balance"));
		return account;

	}
}