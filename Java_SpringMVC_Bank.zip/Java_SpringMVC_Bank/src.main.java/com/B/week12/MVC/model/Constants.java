package com.B.week12.MVC.model;

import org.springframework.stereotype.Component;

@Component
public class Constants {
	
	public static final String SUCCESSFUL_REGISTRATION_MSG="Account Created Successfully!!";

}